import{j as s}from"./index-ucjaFFwd.js";const t=({className:e=""})=>s.jsx("div",{className:`animate-pulse bg-ink/[0.07] rounded-xl ${e}`,"aria-hidden":!0});export{t as S};
